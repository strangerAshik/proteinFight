<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class frontController extends Controller
{
	//provide the last provided contact infos

   
    public  function home(){
    	//contact info
    	$page='home';
      
      //return count($sliderImage);

    	return view('front.welcome',compact('page'))
    			
    	;
    }
    
 
    public function about(){
      $page='about';
      return view('front.about',compact('page'));
    }
    public function blog(){
      $page='Blog';
      return view('front.blog',compact('page'));
    }
    public function career(){
      $page='Career';
      return view('front.career',compact('page'));
    }
    public function investroRelations(){
    	$page='Investor Relations';
    	return view('front.investroRelations',compact('page'));
    }
    Public function ingredient(){
      $page='Ingredient';
      return view('front.ingredient',compact('page'));
    }
    Public function technology(){
      $page='Technology';
      return view('front.technology',compact('page'));
    }
    Public function partnerProject(){
      //return 'Hello';
      $page='Partner Projects';
      return view('front.partnerProject',compact('page'));
    }
    public function contact(){
    	$page='contact';
    	return view('front.contact',compact('page'));
    }
 
  //contact email
  public function sendEmail(Request $request){
    //return 'hello';
    $name=$request->input('name');
    $email=$request->input('email');
    $phone=$request->input('phone');
    $emailMessage=$request->input('message');

    //get contact email
    //$contactEmail=DB::table('contacts')->orderBy('id','desc')->first();
    //mail 

  //$to = $contactEmail->email;
  $to = 'md.ashikuzzaman.ashik@gmail.com';
  $subject ='Email Form Interior Valley';

  $message = "
  <html>
  <head>
  <title>HTML email</title>
  </head>
  <h2>$subject</h2>
  <body>
    $emailMessage
    <p>Name: $name</p>
    <p>Phone: $phone</p>
    <p>Email: $email</p>
  </body>
  </html>
  ";

  // Always set content-type when sending HTML email
  $headers = "MIME-Version: 1.0" . "\r\n";
  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

  // More headers
  $headers .= 'From: <contacts@interiorvalley.com>' . "\r\n";
  //$headers .= 'Cc: myboss@example.com' . "\r\n";

  mail($to,$subject,$message,$headers);
  return back()->with('message','Message Send!');
  }
//subscribe
  public function subscribe(Request $request){
    //return 'hello';
  
  	$email=$request->input('email');
  
  	//get contact email
  	//$contactEmail=DB::table('contacts')->orderBy('id','desc')->first();
  	//mail 

  //$to = $contactEmail->email;
	$to = 'md.ashikuzzaman.ashik@gmail.com';
	$subject ='Subscriber Email Address Form Interior Valley';

	$message = "
	<html>
	<head>
	<title>HTML email</title>
	</head>
	<h2>$subject</h2>
	<body>
		
   
    <p>Email: $email</p>
	</body>
	</html>
	";

	// Always set content-type when sending HTML email
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	// More headers
	$headers .= 'From: <subscribe@interiorvalley.com>' . "\r\n";
	//$headers .= 'Cc: myboss@example.com' . "\r\n";

	mail($to,$subject,$message,$headers);
	return back()->with('message','You are Successfully Subscribed');
  }
  
}
